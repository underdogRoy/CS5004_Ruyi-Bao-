/**
 * Enumeration type for months of the year
 * <p>
 * Needed for Magazine class
 */
public enum Month {
  JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY,
  AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER
}
